## 6.0.14

* Updates code for new analysis options.
* Removes dependency on `meta`.

## 6.0.13

* Splits from `url_launcher` as a federated implementation.
