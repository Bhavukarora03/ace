package dev.davidcobbina.portfolio_site

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
