import 'package:aerium/core/layout/adaptive.dart';
import 'package:aerium/core/utils/functions.dart';
import 'package:aerium/presentation/pages/portfolio/portfolio_page.dart';
import 'package:aerium/presentation/widgets/app_drawer.dart';

import 'package:aerium/presentation/widgets/content_wrapper.dart';
import 'package:aerium/presentation/widgets/socials.dart';
import 'package:aerium/presentation/widgets/spaces.dart';
import 'package:aerium/values/values.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:animated_text_kit/animated_text_kit.dart';

import 'home_page.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';

class HomePageMobile extends StatefulWidget {
  @override
  _HomePageMobileState createState() => _HomePageMobileState();
}

class _HomePageMobileState extends State<HomePageMobile>
    with TickerProviderStateMixin {

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
 // AnimatedBackground(vsync:this, behaviour: RandomParticleBehaviour(), child: Text('abc'))
  @override
  Widget build(BuildContext context) {
    ThemeData theme = Theme.of(context);
    return Scaffold(
      key: _scaffoldKey,
      drawer: AppDrawer(
        menuList: Data.menuList,
        selectedItemRouteName: HomePage.homePageRoute,
      ),
      body: Container(
        child: Stack(
          children: [
            Column(
              children: [
                Row(
                  children: [
                    ContentWrapper(
                      width: assignWidth(context: context, fraction: 0.8),
                      color: AppColors.primaryColor,
//                        gradient: Gradients.primaryGradient,
                      child: Container(
                        child: Column(
                          //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 80,
                            ),

                            Padding(
                              padding: const EdgeInsets.only(right: 10.0),
                              child: Image.asset('assets/images/title_icon.png',
                                  scale: 3),
                            ),
                            SizedBox(
                              height: 50,
                            ),

                            Column(
                              children: [


                                    Row(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(left:35.0),
                                          child: Text(
                                            "HEY! ",
                                            style:  TextStyle(

                                              fontFamily: "samarkan",
                                              fontSize: 18,
                                              color: Colors.teal,
                                              letterSpacing: 2,
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                        ),


                                          Padding(
                                            padding: const EdgeInsets.only(left: 8.0),
                                            child: Text(
                                              "I'm Bhavuk",
                                              style:  TextStyle(
fontFamily: "leaguespartanmaster",

                                                fontSize: 24,
                                                letterSpacing: 2,
                                                fontWeight: FontWeight.w900,
                                              ),
                                            ),
                                          ),

                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(right: 2.0),
                                      child: Container(
                                        margin:  EdgeInsets.only(top: 10),
                                        height: 3.2,
                                        width: 80,
                                        decoration: const BoxDecoration(
                                          color: Colors.teal,
                                        ),
                                      ),
                                    ),

                                  // child: RichText(
                                  //   text: TextSpan(
                                  //       text: "I'm ",
                                  //       style: TextStyle(
                                  //         fontFamily: 'samarkan',
                                  //         letterSpacing: 5,
                                  //         color: Colors.white,
                                  //         fontSize: 20,
                                  //         fontWeight: FontWeight.w900,
                                  //       ),
                                  //       children: [
                                  //         TextSpan(
                                  //           text: "BHAVUK",
                                  //           style: GoogleFonts.notoSansArabic(color: Colors.teal, fontWeight: FontWeight.w900,)
                                  //         )
                                  //       ]
                                  //   ),
                                  // ),

                              ],
                            ),
                            SizedBox(height: 30),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: const EdgeInsets.only(left: 40.0),
                                    child: Text("I'm a",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w800))),
                              ],
                            ),
                            SizedBox(height: 5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 40.0),
                                  child: AnimatedTextKit(
                                    repeatForever: true,
                                    animatedTexts: [
                                      TypewriterAnimatedText(
                                          'Flutter Developer'.toUpperCase(),
                                          speed: Duration(milliseconds: 120),
                                          textStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                          )),
                                      TypewriterAnimatedText(
                                          'Game Developer'.toUpperCase(),
                                          speed: Duration(milliseconds: 120),
                                          textStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                          )),
                                      TypewriterAnimatedText(
                                          'UI/UX Designer'.toUpperCase(),
                                          speed: Duration(milliseconds: 120),
                                          textStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                          )),
                                      TypewriterAnimatedText(
                                          'Photographer'.toUpperCase(),
                                          speed: Duration(milliseconds: 120),
                                          textStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                            fontWeight: FontWeight.w500,
                                          )
                                      )],
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 100),
                            Padding(
                              padding: const EdgeInsets.only(left: 40),
                              child: NeumorphicButton(
                                  onPressed: () {
                                    Functions.launchUrl(StringConst.PORTFOLIO_URL);
                                  },
                                  style: NeumorphicStyle(


                                    color: Colors.teal,
                                    shape: NeumorphicShape.flat,
                                    boxShape: NeumorphicBoxShape.roundRect(
                                        BorderRadius.circular(30)),
                                  ),
                                  padding:
                                      const EdgeInsets.fromLTRB(40, 10, 40, 10),
                                  child: Text(
                                    'Resume'.toUpperCase(),
                                    style: TextStyle(
                                        fontFamily: "leaguespartanmaster", fontSize: 12, letterSpacing: 3),
                                  )),
                            ),
                            Spacer(flex: 1),
                            InkWell(
                              onTap: () {
                                Navigator.pushNamed(
                                  context,
                                  PortfolioPage.portfolioPageRoute,
                                );
                              },
                              child: Container(
                                padding: const EdgeInsets.only(left: 24.0),
                                child: Column(
                                  children: [
                                    RotatedBox(
                                      quarterTurns: 3,
                                      child: Text(
                                        StringConst.VIEW_PORTFOLIO,
                                        textAlign: TextAlign.end,
                                        style:
                                            theme.textTheme.bodyText1!.copyWith(
                                          color: AppColors.secondaryColor,
                                          fontSize: 12,
                                              fontFamily: "leaguespartanmaster",
                                        ),
                                      ),
                                    ),
                                    SpaceH12(),
                                    NeumorphicButton(
                                      padding: EdgeInsets.all(6),
                                        style: NeumorphicStyle(



                                          color: Colors.black12,
                                          shape: NeumorphicShape.concave,
                                          boxShape:
                                          NeumorphicBoxShape.roundRect(BorderRadius.circular(100)),
                                        ),
                                      onPressed: () {
                                        Navigator.pushNamed(context,
                                            PortfolioPage.portfolioPageRoute);
                                      },
                                      child: Icon(
                                          Icons.keyboard_arrow_down,

                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(
                              height: assignHeight(
                                context: context,
                                fraction: 0.05,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    ContentWrapper(
                      width: assignWidth(context: context, fraction: 0.2),
                      color: AppColors.secondaryColor,
                      child: Container(),
                    ),
                  ],
                )
              ],
            ),
            _buildAppBar(),
            //_buildDevImage(),
            _buildSocials(),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: Sizes.PADDING_16,
        vertical: Sizes.PADDING_16,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          NeumorphicButton(
            padding: EdgeInsets.all(6),
              style: NeumorphicStyle(
                depth: 3,

                color: Colors.black12,
                shape: NeumorphicShape.convex,
                boxShape:
                    NeumorphicBoxShape.roundRect(BorderRadius.circular(100)),
              ),
              onPressed: () {
                if (_scaffoldKey.currentState!.isEndDrawerOpen) {
                  _scaffoldKey.currentState!.openEndDrawer();
                } else {
                  _scaffoldKey.currentState!.openDrawer();
                }
              },
              child: Icon(
                Icons.menu_sharp,
              )),
          NeumorphicButton(
            padding: EdgeInsets.all(8),
            style: NeumorphicStyle(
              color: Colors.white,
              shape: NeumorphicShape.convex,
              boxShape:
                  NeumorphicBoxShape.roundRect(BorderRadius.circular(1000)),
            ),
            onPressed: () {
              Functions.launchUrl(StringConst.EMAIL_URL);
            },
            child: Icon(
              Icons.mail_rounded,
              color: Colors.black,
            ),
          )
        ],
      ),
    );
  }

  // Widget _buildDevImage() {
  //   return Positioned(
  //     top: 56,
  //     right: -assignWidth(context: context, fraction: 0.42),
  //     child: Container(
  //       child: Image.asset(
  //         ImagePath.DEV,
  //         height: 1000,
  //         fit: BoxFit.cover,
  //       ),
  //     ),
  //   );
  // }

  Widget _buildSocials() {
    return Positioned(
      right: Sizes.SIZE_16,
      bottom: Sizes.SIZE_30,
      child: Socials(
        isVertical: true,
        alignment: Alignment.centerRight,
        color: AppColors.primaryColor,
        barColor: AppColors.secondaryColor,
        crossAxisAlignment: CrossAxisAlignment.end,
      ),
    );
  }
}
