import 'package:flutter/material.dart';
import 'package:aerium/values/values.dart';

class Emptiness extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: Sizes.WIDTH_0,
      height: Sizes.HEIGHT_30,
    );
  }
}
