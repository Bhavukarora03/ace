part of values;

class DocumentPath {
  //Docs route
  static const String docDir = "assets/docs";

  //Docs
  static const String CV = "$docDir/Bhavuk_CV.pdf";
}
