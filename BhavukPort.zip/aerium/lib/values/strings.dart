part of values;

class StringConst {
  //strings
  static const String APP_NAME = "Bhavuk";
  static const String APP_TITLE = "Bhavuk Arora";
  //static const String SITE_URL = "https://davidcobbina.com";

  static const String HOME = "Home";
  static const String LOGONAME = "<BHAVUK>";
  static const String ABOUT_ME = "About Me";
  static const String PORTFOLIO = "Portfolio";
  static const String EXPERIENCE = "Experience";
  static const String WORK = "Where I've Worked";
  static const String SERVICES = "Services";
  static const String CONTACT = "Contact";
  static const String PHONE_NUMBER = "Phone Number";
  static const String RESUME = "Resume";
  static const String CERTIFICATIONS = "Certifications";
  static const String EMAIL_VALUE = "Bhavuk.arora03@gmail.com";

  static const String MESSAGE_ME = "Message me";
  static const String GET_IN_TOUCH = "Get in touch";
  static const String VIEW = "View";
  static const String COMING_SOON = "COMING SOON !!";
  static const String BUILT_WITH = "Built with ";
  static const String DEV_EMAIL = "Bhavukarora03@gmail.com";
  static const String EMAIL_URL = "mailto:<$DEV_EMAIL>?subject=&body=";

  static const String KEY_SKILLS = "KEY SKILLS";
  static const String EXPERIENCE_2 = "EXPERIENCE";
  static const String EDUCATION = "EDUCATION";

  static const String SEND_ME_A_MESSAGE = "Send me a message";
  static const String VIEW_PORTFOLIO = "View Portfolio";

  static const String PROJECT_NAME = "Project Name";

  static const String INTRO = "Hi, My name is";
  static const String DEV_NAME = "Bhavuk Arora";
  static const String PUNCH_LINE = "I build things with flutter";
  static const String SPECIALITY = "FLUTTER DEV";
  static const String DESIGNED_IN = "Made with ";
  static const String DESIGNED_BY = "";
  static const String BUILT_BY = "by Bhavuk Arora ";

  static const String ABOUT_DEV_TEXT =
      "I'm a Computer Science Student based in India, looking forward to collaborate with an organization which helps enhance my skills, learn something new, think out of the box and explore more in a professional manner in the management of computer information system specific areas of interest includes Flutter, Photography, Unity and UI/UX";

  static const String EDUCATION_TEXT =
      "Hey, this is Bhavuk from delhi. I am a sophomore at Vivekananda institute of professional "
      "studies pursuing bachelor of computer applications. I am  aiming to be a flutter developer."
      " I also have a keen interest in game development. I started my under-graduation as an indie-game developer, using UNITY ENGINE. "
      "I was extremely driven by app development and gained some expertise with DART and flutter. I have also worked with different state-management techniques, "
      " dependency injection, working with data models, tensor-flow, and many AI components as well. "
      "In the field of UI/UX I have tried out and gained massive experience with tools like FIGMA and ADOBE SUITE";

  //Form Hint Texts
  static const String NAME_HINT_TEXT = "Name";
  static const String PHONE_HINT_TEXT = "Phone (Optional)";
  static const String EMAIL_HINT_TEXT = "Email";
  static const String MESSAGE_HINT_TEXT = "Message";

  static const String SEND_MESSAGE = "Send Message";

  //Skills
  static const String FLUTTER = "FLUTTER";

  static const String UIUX = "UI/UX";
  static const String UNITY = "UNITY";
  static const String Languages = "C++/C#/JAVA";
  static const String CSHARP = "C#";
  static const String ADOBEXD = "ADOBE XD";
  static const String GIT = "GIT";
  static const String OPENCORE = "OPENCORE";
  static const String FINALCUTPRO = "FINAL CUT PRO";
  static const String ADOBE_SUITE = "ADOBE SUITE";
  static const String HTML_CSS = "HTML/CSS/SQFLITE";

  //routes
  static const String HOME_PAGE = "/";
  static const String ABOUT_PAGE = "/about";
  static const String PORTFOLIO_PAGE = "/portfolio";
  static const String CONTACT_PAGE = "/contact";
  static const String PROJECT_PAGE = "/project";
  static const String PROJECT_DETAIL_PAGE = "/project-detail";
  static const String SERVICES_PAGE = "/services";
  static const String MESSAGE_PAGE = "/message-me";
  static const String EXPERIENCE_PAGE = "/experience";
  static const String RESUME_PAGE = "/resume";
  static const String CERTIFICATION_PAGE = "/certifications";

  //Socials
  static const String GITHUB_URL = "https://github.com/Bhavukarora03";
  static const String LINKED_IN_URL =
      "https://www.linkedin.com/in/bhavuk-arora-4a7263216/";
  static const String TWITTER_URL = "https://www.instagram.com/damocles2x/";
  static const String INSTAGRAM_URL = "https://www.instagram.com/damocles2x";
  static const String TELEGRAM_URL = "https://www.reddit.com/user/Bhavuk15";
  static const String PORTFOLIO_URL = "https://drive.google.com/file/d/102J65G3Bb66bcZoJM-7FBLpZLE3odzD9/view?usp=sharing";

  //Contacts
  static const String CONNECT = "Connect with me";
  static const String EMAIL = "Email";
  static const String LINKED_IN = "LINKEDIN";
  static const String TWITTER = "TWITTER";
  static const String INSTAGRAM = "INSTAGRAM";
  static const String TELEGRAM = "TELEGRAM";

  //Certificate Urls
  static const String ASSOCIATE_ANDROID_DEV_URL =
      "https://www.credential.net/b296da88-d6be-4bb5-9756-b13efea3a421";
  static const String DATA_SCIENCE_CERT_URL =
      "https://graduation.udacity.com/confirm/7CGEJAFR";
  static const String ANDROID_BASICS_CERT_URL =
      "https://graduation.udacity.com/confirm/9VTDRN5K";

  //AwardedBy
  static const String GOOGLE = "Google";
  static const String UDACITY = "Udacity";

  //CertificationType
  static const String ASSOCIATE_ANDROID_DEV = "UNITY DEVELOPER";
  static const String DATA_SCIENCE = "FLUTTER";
  static const String ANDROID_BASICS = "UI/UX";

  //Experience
  static const String CURRENT_MONTH_YEAR = "Current";
  static const String STARTED_MONTH_YEAR = "March 2019";

  static const String COMPANY_1 = "FREELANCER";
  static const String COMPANY_1_URL = "";
  static const String POSITION_1 = "College Dropout";
  static const String COMPANY_1_ROLE_1 =
      "Built a Block Breaker Game using UNITY and C#. Integrated Firebase for authentication and Local Storage for state management";
  static const String COMPANY_1_ROLE_2 =
      "Learnt about Unity Engine and C# as my first programming Language";
  static const String COMPANY_1_ROLE_3 =
      "Enrolled into various online courses includes Music instrumentalist, Interior Designer and activities includes Youtube, Photography to gain field experience";
  static const String LOCATION_1 = "Panipat - Haryana";
  static const String DURATION_1 = "May 2019 - July 2020";

  static const String COMPANY_2 = "WORKSHOPS";
  static const String COMPANY_2_URL = "";
  static const String POSITION_2 = "Game Jams";
  static const String COMPANY_2_ROLE_1 =
      "Joined ACE the technical Society of VSIT, VIPS and working as a core member for game dev, \nEvent Coordinator at Gender Champions Club  \n Photographer at Frames - The Photography Society of VSIT, VIPS";
  static const String COMPANY_2_ROLE_2 =
      "Participated in Breckeys game jam 2021 and Built and Polished the User experience of the Game => Panzer";
  static const String COMPANY_2_ROLE_3 =
      "Participated in BYOG India Game Jam 2021 and enhanced the UX by Creating a Retro theme Game => Two 3rd Dimension";
  static const String COMPANY_2_ROLE_4 =
      "Worked on Combined Project => COVIRUS as a UI/UX Designer";
  static const String LOCATION_2 = "Rohini - Delhi";
  static const String DURATION_2 = "Jan 2021 - Present";

  static const String COMPANY_3 = "INTERNSHIP";
  static const String COMPANY_3_URL = "";
  static const String POSITION_3 = "UI/UX";
  static const String COMPANY_3_ROLE_1 =
      "Started Flutter in Autumn 2021 and never stopped learning since then :p. Built basic to Intermediate level apps includes Dice Roll, Xylophone, Quizie";
  static const String COMPANY_3_ROLE_2 =
      "Working as a AR/VR developer as a Intern under Indian Institute of Technology, DELHI";
  static const String COMPANY_3_ROLE_3 =
      "Gained some more Programming and Framework knowledge includes C, C++, MySQL,.NET, HTML/CSS, GIT, Opencore";
  static const String COMPANY_3_ROLE_4 =
      "Worked on a paid internship under college faculty for Hammonia Energy, Germany. as a Document manager and video editor \nTime Period - 2 months";
  static const String LOCATION_3 = "Rohini- Delhi";
  static const String DURATION_3 = "September 2021 - Present";

  static const String COMPANY_4 = "FLUTTER DEV";
  //static const String COMPANY_4_URL = SITE_URL;
  static const String POSITION_4 = "Flutter UI/UX";
  static const String COMPANY_4_ROLE_1 =
      "Worked collaboratively with a user experience designer to bring mobile and progressive apps to life using Flutter.";
  static const String COMPANY_4_ROLE_2 =
      "Wrote modern, performant, maintainable code for a client and personal open source projects includes: "
      "\n - Body mass Index Calculator"
      "\n - Weather App Using OpenWeather API, https for network Requests"
      "\n - To-do App using Riverpod for state management "
      "\n - Messenger using Firebase auth and firestore for storage";
  static const String COMPANY_4_ROLE_3 =
      "Work with a variety of different languages, platforms, frameworks, and content management systems such as Dart, Adobe XD, Opencore, Adobe After effects, Final Cut pro";
  static const String COMPANY_4_ROLE_4 =
      "Interface with clients and provide technological expertise";
  static const String LOCATION_4 = "Rohini - Delhi";
  static const String DURATION_4 = "Jan 2021 - Current";

  //Portfolio, Projects
  static const String Weather_APP = "BotStorm";
  static const String Weather_app_subtitile = "A beautiful Weather APP";
  static const String Weatherapp_desc =
      "BotStorm is a weather app developed in Flutter using Single API. It uses Firebase push service notifications to send weather notifications. Not only the app predicts upcoming 5 days weather data but the current location as well";

  static const String Weatherapp_url =
      "https://github.com/david-legend/login_catalog";

  static const String two3d_titile = "TWO 3rd DIMENSIONS";
  static const String two3d_subtitile = 'Based on two Views';

  static const String two3d_details =
      'Two Third Dimensions is a Unity game made for BYOG gamejam 2021.It is based on based on Two-views prespective. Go play and Rate us on ITCH.IO';

  static const String two3d_url =
      "https://github.com/Bhavukarora03/Two-Third-Dimension.git";

  static const String BMI_CAL = "BODY MASS INDEX";
  static const String BMI_CAL_SUB = "CALCULATOR";
  static const String BMI_CAL_DETAILS =
      "Body Mass Index  Calculator is a measurement of a person's leanness or corpulence based on their height and weight, and is intended to quantify tissue mass. The app was inspired from Neumorphism style and designed in FIGMA and made in FLUTTER";
  static const String BMI_CAL_GITHUB_URL =
      "https://github.com/Bhavukarora03/BMI__cal.git";

  static const String ToDo_title = "JUST DO IT";
  static const String Todo_subtitile = "Task Management App";
  static const String todo_appdetail =
      "Todoey is an app that takes you through an elegant Task Management Experience. Build using Getx for state management and routing and Hive and for local storage";
  static const String Todo_app_url =
      "https://github.com/david-legend/onbording-app";

  static const String Ace_app_titile = "ACE";
  static const String Ace_app_subtitile = "That Connects Society";
  static const String ace_app_details =
      'In development Stage (Stay Tuned)- ACE is an for My college technical Society.';

  static const String ace_app_url = "";

  static const String Messenger_titile = "MESSENGER";
  static const String messenger_subtitile = 'Yes, You saw that right!';
  //"Beautifully designed website that expresses the services provided by the company.";
  static const String Messenger_details =
      'Messenger uses firebase auth for authenticating users and firestore for storing streams of messages in the cloud';

  static const String Messenger_url =
      "https://github.com/Bhavukarora03/messcenger.git";

  static const String Bhavuk_Port = "Bhavuk";
  static const String Bhavuk_portfolio_subtitile =
      "A progressive web app for my portfolio.";
  static const String bhavuk_portfolio_details =
      "This Portfolio was entirely made in FLUTTER using FLUTTER web. using flutter bloc pattern and responsive builder. This is the beauty of FlUTTER web ";
  static const String Portfolio_url = '';

  static const String Panzer_titile = "PANZER";
  static const String Panzer_subtitile = "UNITY GAME";
  static const String Panzer_details =
      "Developed in 72 hours for Breckeys Game Jam, Panzer is a windows game developed in Unity using C# and is based on outer space survival in a tank while defeating golems";
  static const String Panzer_url =
      "https://github.com/Bhavukarora03/Panzer-UNITY";

  static const String CIRCE = "Circe";
  static const String PROXIMA_NOVA = "ProximaNova";

  //API
  static const String BASE_URL =
      "https://asqbx1u5bg.execute-api.us-east-1.amazonaws.com/production/";
  static const String SEND_END_POINT = "send";
}
